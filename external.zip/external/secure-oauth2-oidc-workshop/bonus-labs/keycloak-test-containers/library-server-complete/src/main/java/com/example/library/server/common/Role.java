package com.example.library.server.common;

public enum Role {
  LIBRARY_USER,

  LIBRARY_CURATOR,

  LIBRARY_ADMIN
}
