# Testing the library server application with custom mapping

This is the completed reference of the library resource server application containing
the completed automated end2end test.