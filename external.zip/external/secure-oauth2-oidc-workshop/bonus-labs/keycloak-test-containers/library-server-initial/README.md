# Testing the library server application with custom mapping

This is the initial version of the library resource server application containing
the base for the automated end2end test.