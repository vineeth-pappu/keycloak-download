package micronaut.server.app;

import io.micronaut.runtime.Micronaut;

public class MicronautServerApp {

  public static void main(String[] args) {
    Micronaut.run(MicronautServerApp.class);
  }
}
