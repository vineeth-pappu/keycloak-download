package com.example.multitenant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiTenantServerAppApplicationTests {

  @Test
  void contextLoads() {}
}
