package com.example.github;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitHubClientApplication {

  public static void main(String[] args) {
    SpringApplication.run(GitHubClientApplication.class, args);
  }
}
