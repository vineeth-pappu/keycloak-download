export interface ResponseBase {
  message: string;
  isError: boolean;
}
