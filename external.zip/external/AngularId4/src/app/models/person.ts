export interface Person {
  id: number;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  fullName: string;
}
