# AngularKeycloakExample

This project is a working example for connecting Keycloak to Angular. See [this article](https://medium.com/@blained3/connecting-keycloak-to-angular-d175c92a0dd3) I wrote to find out more!
