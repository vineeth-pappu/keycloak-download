const SecretBooks = () => (
  <div className="jumbotron">
    <h1>️️⚡️ Here are some secret books! ⚡️</h1>
  </div>
)

export default SecretBooks
