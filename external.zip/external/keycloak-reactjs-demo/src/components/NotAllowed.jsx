const NotAllowed = () => (
  <h1 className="text-info">Access is not allowed! ⛔️</h1>
)

export default NotAllowed
